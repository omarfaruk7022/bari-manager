import Bill from '../models/Bill.model.js'
import Payment from '../models/Payment.model.js'
import Expense from '../models/Expense.model.js'
import Tenant from '../models/Tenant.model.js'

export const monthly = async (req, res, next) => {
  try {
    const { month } = req.query
    if (!month) return res.status(400).json({ success: false, message: 'মাস দিন (যেমন: 2025-01)' })

    const landlordId = req.user._id

    const [bills, payments, expenses, activeTenants] = await Promise.all([
      Bill.find({ landlordId, month }),
      Payment.find({ landlordId, status: 'success', createdAt: { $regex: month } }),
      Expense.find({ landlordId, month }),
      Tenant.countDocuments({ landlordId, isActive: true }),
    ])

    const totalBilled    = bills.reduce((s, b) => s + b.totalAmount, 0)
    const totalCollected = bills.reduce((s, b) => s + b.paidAmount, 0)
    const totalDue       = bills.reduce((s, b) => s + b.dueAmount, 0)
    const totalExpenses  = expenses.reduce((s, e) => s + e.amount, 0)
    const profit         = totalCollected - totalExpenses

    const statusBreakdown = {
      paid:    bills.filter((b) => b.status === 'paid').length,
      partial: bills.filter((b) => b.status === 'partial').length,
      unpaid:  bills.filter((b) => b.status === 'unpaid').length,
    }

    res.json({
      success: true,
      data: {
        month,
        activeTenants,
        totalBilled,
        totalCollected,
        totalDue,
        totalExpenses,
        profit,
        statusBreakdown,
        bills,
      },
    })
  } catch (err) { next(err) }
}

export const yearly = async (req, res, next) => {
  try {
    const year = req.query.year || new Date().getFullYear()
    const landlordId = req.user._id

    const months = Array.from({ length: 12 }, (_, i) => {
      const m = String(i + 1).padStart(2, '0')
      return `${year}-${m}`
    })

    const results = await Promise.all(
      months.map(async (month) => {
        const bills    = await Bill.find({ landlordId, month })
        const expenses = await Expense.find({ landlordId, month })
        const collected = bills.reduce((s, b) => s + b.paidAmount, 0)
        const expTotal  = expenses.reduce((s, e) => s + e.amount, 0)
        return { month, collected, expenses: expTotal, profit: collected - expTotal }
      })
    )

    const totalCollected = results.reduce((s, r) => s + r.collected, 0)
    const totalExpenses  = results.reduce((s, r) => s + r.expenses, 0)

    res.json({
      success: true,
      data: {
        year,
        monthlyBreakdown: results,
        totalCollected,
        totalExpenses,
        totalProfit: totalCollected - totalExpenses,
      },
    })
  } catch (err) { next(err) }
}
